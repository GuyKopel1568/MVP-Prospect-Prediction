# NBA-s-MVP-Predictor
FinalProject
--

לינק לסרטון: 
--

[לינק לסרטון גוגל דרייב](https://drive.google.com/file/d/1jOZTShFsRjnbLT4JPmWf2p7Eo1qP_ZJS/view?usp=sharing)
--

[לינק לסרטון ביוטיוב](https://www.youtube.com/watch?v=YMJLu4oWfWs&ab_channel=NivOzer)
--

פרוייקט סוף מדעי הנתונים : Mvp Prospect Prediction
--

קובץ  הJupyter נשמר בשם "Jupyter" 
--

קובץ מסמך ה word נשמר בשם סיכום1500 
--

המצגת שמורה בשם מצגת מדעי הנתונים.pptx  
--

כל קבצי הפייתון והקבצים הנוספים נמצאים בפנים
--

